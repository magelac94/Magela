package PARCIAL1;



public class Conjunto<E> extends Lista<E> implements IConjunto<E> {

     
    @Override
    public IConjunto complemento(IConjunto conjuntoUniversal) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override   // aseguramos que no se inserten duplicados
     public void insertar(INodo<E> nodo) {
         if (buscar(nodo.getEtiqueta())== null){
             super.insertar(nodo);
         }
        
    }

}
