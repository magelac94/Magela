package PARCIAL1;

public interface IAlumno {

        /**
     * Retorna el apellido / nombre del Alumno.
     *
     * @return el apellido / nombre del Alumno.
     */
    public String getNombre();

}
