﻿package  parcial2;




public class Main {

    /**
     * @param args
     */
    public static void main(String[] args) {
        TArbolBB arbol = new TArbolBB();

         TArbolBB arbol = new TArbolBB();

        // leer las claves del archivo "claves.txt" e insertar en el árbol nodos con estas claves
		// ATENCIÓN: LAS CLAVES SON NUMEROS ENTEROS, Y DEBEN SER TRATADOS COMO TALES 
		
		// invocar al método nivelDeHojas() y emitir por consola el resultado
		

}

}
